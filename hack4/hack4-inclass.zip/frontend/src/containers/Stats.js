import WatchList from '../components/WatchList';

import "./Stats.css";

export default function Stats() {

    return <div className="Stats">
        <WatchList />
    </div>
}
