import db from './db';  // see the README for how to manipulate this object

// TODO
// Setup the GraphQL server